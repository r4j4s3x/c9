function simpleFunction() {
}

function simpleFunctionNested(a, b) {
    function nested(c) {
    }
}

(function() {
    var someFunction = function(a, b) {
    };
    
    someFunction.bla = function() {
        this.foo = {
            a: function () {
                
            },
            b: function gbk() {
                
            },
            c: {
                a: function () {
                    
                },
                b: function gbk() {
                    
                },
                x: 1
            },
            d: 1
        };
        this.on("listen", function() {
        
        });
    };
})();


a.b[x] = function() {
    
};

a.b.c = function() {
    
};

handler = function() {
    
};

alias = handler = function() {
    
};